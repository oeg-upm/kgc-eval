#!/bin/bash

python3 rdfizer/run_rdfizer.py $1

