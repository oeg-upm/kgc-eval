from rdfizer.semantify import semantify
import sys
semantify(str(sys.argv[1]))
